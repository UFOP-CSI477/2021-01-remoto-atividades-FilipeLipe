## Front-end codigo livre

A parte do front-end que utilizei é um código livre, no site: https://adminlte.io/blog/free-admin-panels eles disponibilizam e pode ser baixado atravez do link: https://github.com/puikinsh/srtdash-admin-dashboard

# Versões
- Sistema Operacional - Por enquanto ainda é o windows 10
- Laravel - 8.78.0.
- PHP - 8.1.1
- Banco de dados - SQLITE - 3.37.0